import React from 'react';
import './Style.css';

function Help() {
    return <div className="help">
            <h1>Help</h1>
            </div>;
  }
  
export default Help;