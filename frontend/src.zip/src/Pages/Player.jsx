import React from 'react';
import './Style.css';

function Player() {
    return <div className="player">
            <h1>Hello, Viktorio!</h1>
            username: Viktorio <br></br>
            email: viktorio@dartssense.com
            </div>;
  }
  
export default Player;